#include <iostream>
#include <fstream>
#include <map>
#include <string>
using namespace std;

// Menu display function
void displayMenu() {
    cout << "1. Search for a specific word and display its frequency.\n";
    cout << "2. Display the frequency of all words.\n";
    cout << "3. Display a histogram of word frequencies.\n";
    cout << "4. Exit.\n";
}

// Function to read data from a file and store frequencies in a map
map<string, int> readDataFromFile(const string& filename) {
    map<string, int> frequencyMap;
    ifstream file(filename);
    string word;

    if (file.is_open()) {
        while (file >> word) {
            frequencyMap[word]++;
        }
        file.close();
    }
    else {
        cout << "Unable to open file: " << filename << endl;
    }

    return frequencyMap;
}

// Word search function
void searchWord(const map<string, int>& frequencyMap) {
    string word;
    cout << "Enter the word you want to search for: ";
    cin >> word;

    auto it = frequencyMap.find(word);
    if (it != frequencyMap.end()) {
        cout << "The word \"" << word << "\" appears " << it->second << " time(s).\n";
    }
    else {
        cout << "The word \"" << word << "\" does not appear in the file.\n";
    }
}

// Function to display all word frequencies
void displayFrequencies(const map<string, int>& frequencyMap) {
    cout << "Word Frequencies:\n";
    for (const auto& pair : frequencyMap) {
        cout << pair.first << " " << pair.second << endl;
    }
}

// Function to display a histogram
void displayHistogram(const map<string, int>& frequencyMap) {
    cout << "Word Histogram:\n";
    for (const auto& pair : frequencyMap) {
        cout << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            cout << "*";
        }
        cout << endl;
    }
}

// Function to save frequencies to a file
void saveFrequenciesToFile(const map<string, int>& frequencyMap, const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        for (const auto& pair : frequencyMap) {
            file << pair.first << " " << pair.second << endl;
        }
        file.close();
        cout << "Data saved to " << filename << endl;
    }
    else {
        cout << "Unable to open file: " << filename << endl;
    }
}

// Main function
int main() {
    // I had to get the exact file location to work on my PC. It may work for you by substituting the path with CS210_Project_Three_Input_File.txt.
    const string inputFilename = "C:\\Users\\heath\\OneDrive\\Desktop\\ChadaFrequency\\ChadaFrequency\\x64\\Debug\\CS210_Project_Three_Input_File.txt";
    const string backupFilename = "frequency_backup.dat";

    map<string, int> frequencyMap = readDataFromFile(inputFilename);

    if (!frequencyMap.empty()) {
        saveFrequenciesToFile(frequencyMap, backupFilename);

        int choice;
        do {
            displayMenu();
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) { // Enables menu functionality
            case 1:
                searchWord(frequencyMap);
                break;
            case 2:
                displayFrequencies(frequencyMap);
                break;
            case 3:
                displayHistogram(frequencyMap);
                break;
            case 4:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
            }
        } while (choice != 4);
    }
    else {
        cout << "No data available to process.\n";
    }

    return 0;
}
